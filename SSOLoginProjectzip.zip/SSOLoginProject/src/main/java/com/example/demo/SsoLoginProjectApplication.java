package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsoLoginProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SsoLoginProjectApplication.class, args);
		System.out.println("running the server");
	}

}
