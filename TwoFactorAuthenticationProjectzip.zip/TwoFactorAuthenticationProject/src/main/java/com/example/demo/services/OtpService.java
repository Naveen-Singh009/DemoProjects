package com.example.demo.services;

import java.time.LocalDateTime;
import java.util.Random;

import org.springframework.stereotype.Service;

import com.example.demo.models.User;

@Service
public class OtpService {

    public String generateOtp() {
        return String.valueOf(100000 + new Random().nextInt(900000));
    }

    public boolean isOtpValid(User user, String otp) {
        return user.getOtp().equals(otp)
            && user.getOtpExpiry().isAfter(LocalDateTime.now());
    }
}

