package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TwoFactorAuthenticationProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TwoFactorAuthenticationProjectApplication.class, args);
		System.out.println("Server is running fine");
	}

}
